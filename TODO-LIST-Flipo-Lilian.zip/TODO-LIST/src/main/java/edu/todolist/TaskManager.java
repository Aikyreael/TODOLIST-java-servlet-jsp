package edu.todolist;


import edu.todolist.model.State;
import edu.todolist.model.Task;

import java.util.ArrayList;

public class TaskManager extends ArrayList<Task> {
    void modifyState(Integer id, State state) {
        for (Task task : this) {
            if (task.getId().equals(id)) {
                task.setState(state);
            }
        }
    }
}
