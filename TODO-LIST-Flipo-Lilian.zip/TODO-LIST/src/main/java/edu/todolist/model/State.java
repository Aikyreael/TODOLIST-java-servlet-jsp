package edu.todolist.model;

public enum State {
    TODO,
    DOING,
    FINISHED,
    DONE
}
