package edu.todolist.model;

public class Task {

    private Integer id;

    private String name;

    private State state;

    private String author;

    public boolean isValid() {
        return id != null
                && !name.isEmpty()
                && state != null
                && !author.isEmpty();
    }

    public Integer getId() {
        return id;
    }

    public Task setId(Integer id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public Task setName(String name) {
        this.name = name;
        return this;
    }

    public State getState() {
        return state;
    }

    public Task setState(State state) {
        this.state = state;
        return this;
    }

    public String getAuthor() {
        return author;
    }

    public Task setAuthor(String author) {
        this.author = author;
        return this;
    }
}

