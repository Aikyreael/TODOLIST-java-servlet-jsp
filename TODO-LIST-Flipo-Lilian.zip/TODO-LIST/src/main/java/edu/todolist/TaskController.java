package edu.todolist;


import edu.todolist.model.State;
import edu.todolist.model.Task;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;


@WebServlet(name = "task", value = "/task")
public class TaskController extends HttpServlet {

    TaskManager taskManager;
    Integer idIncr;

    @Override
    public void init() throws ServletException {
        taskManager = new TaskManager();
        idIncr = 0;
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        idIncr++;

        Task task = new Task();
        task.setId(idIncr)
                .setName(request.getParameter("name"))
                .setState(State.valueOf(request.getParameter("state")))
                .setAuthor(request.getParameter("author"));

        if (task.isValid()) {
            taskManager.add(task);
        }

        request.setAttribute("taskManager", taskManager);

        RequestDispatcher requestDispatcher = request.getRequestDispatcher("index.jsp");
        requestDispatcher.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        if (request.getParameter("state").equals("DONE")) {
            for(int i = (taskManager.size() - 1); i >= 0; i--) {
                if (taskManager.get(i).getId().equals(Integer.parseInt(request.getParameter("id")))) {
                    taskManager.remove(taskManager.get(i));
                }
            }
        } else {
            taskManager.modifyState(
                    Integer.parseInt(request.getParameter("id")),
                    State.valueOf(request.getParameter("state")));
        }

        request.setAttribute("taskManager", taskManager);

        RequestDispatcher requestDispatcher = request.getRequestDispatcher("index.jsp");
        requestDispatcher.forward(request, response);
    }
}
